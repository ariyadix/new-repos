<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\Permission;

class PermissionController extends Controller
{
    //
    public function getPermission($id)
    {
        $permission = Permission::find($id);

        return $permission;
    }
}
