/*
Translation from original CKEDITOR language files:
Copyright (c) 2003-2014, CKSource - Frederico Knabben. All rights reserved.
For licensing, see LICENSE.html or http://ckeditor.com/license
*/
CKEDITOR.plugins.setLang("base64image","ja",{
	"alt":"代替テキスト",
	"lockRatio":"比率を固定",
	"vSpace":"垂直間隔",
	"hSpace":"水平間隔",
	"border":"枠線の幅"
});